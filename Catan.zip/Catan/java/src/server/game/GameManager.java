package server.game;

import java.util.ArrayList;
import java.util.List;

/**
 * This manager stores and retrieves all Games on the current server. This class is meant to be a singleton so the server can access it from anywhere.
 * @author raulvillalpando
 *
 */
public class GameManager {
	
	/**
	 * A list of games stored on the server
	 */
	private List<Game> games = new ArrayList<Game>();
	private int nextID = 0;
		
	public GameManager() {
		
	}
	
	/**
	 * Adds a new game to the existing list
	 * @param newGame
	 */
	public void addGame(Game newGame) {
		games.add(newGame);
		nextID++;
	}
	
	/**
	 * Get a game by its id
	 * @param id The ID of the game to retrieve
	 * @return
	 */
	public Game getGameById(int id) 
	{
		for (Game game : games)
		{
			if (game.getId() == id)
			{
				return game;
			}
		}
		System.out.println("getGameById is returning null");
		return null;
	}
	
	public int getNextId()
	{
		return nextID;
	}
	
	/**
	 * Get the list of existing games
	 * @return
	 */
	public List<Game> getGames() {
		return games;
	}
}
