package client.resources;

import java.util.*;

import shared.definitions.DevCardType;
import shared.definitions.PieceType;
import shared.definitions.ResourceType;
import shared.model.cards.Bank;
import shared.model.cards.DevCard;
import shared.model.cards.ResourceCardDeck;
import shared.model.facade.ModelFacade;
import shared.model.game.TurnManager;
import shared.model.game.User;
import client.base.*;
import client.data.PlayerInfo;
import client.manager.ClientManager;


/**
 * Implementation for the resource bar controller
 */
public class ResourceBarController extends Controller implements IResourceBarController, Observer {

	private Map<ResourceBarElement, IAction> elementActions;
	
	public ResourceBarController(IResourceBarView view) {

		super(view);
		
		elementActions = new HashMap<ResourceBarElement, IAction>();
		ClientManager.instance().getModelFacade().addObserver(this);
	}

	@Override
	public IResourceBarView getView() {
		return (IResourceBarView)super.getView();
	}

	/**
	 * Sets the action to be executed when the specified resource bar element is clicked by the user
	 * 
	 * @param element The resource bar element with which the action is associated
	 * @param action The action to be executed
	 */
	public void setElementAction(ResourceBarElement element, IAction action) {

		elementActions.put(element, action);
	}

	@Override
	public void buildRoad() {				
		executeElementAction(ResourceBarElement.ROAD);
	}

	@Override
	public void buildSettlement() {
		executeElementAction(ResourceBarElement.SETTLEMENT);
	}

	@Override
	public void buildCity() {
		executeElementAction(ResourceBarElement.CITY);
	}

	@Override
	public void buyCard() {
		executeElementAction(ResourceBarElement.BUY_CARD);
	}

	@Override
	public void playCard() {
		executeElementAction(ResourceBarElement.PLAY_CARD);
	}
	
	private void executeElementAction(ResourceBarElement element) {
		
		if (elementActions.containsKey(element)) {
			
			IAction action = elementActions.get(element);
			action.execute();
		}
	}

	@Override
	public void update(Observable o, Object arg) {
		
		//Get the info
		ClientManager cm = ClientManager.instance();
		PlayerInfo player = cm.getCurrentPlayerInfo();
		ModelFacade facade = cm.getModelFacade();
		TurnManager turnManager = facade.turnManager();
		
		int currentID = player.getId();
		
		User currentUser = facade.turnManager().getUserFromID(currentID);
		ResourceCardDeck resourceHand = currentUser.getHand().getResourceCards();
		Bank bank = facade.bank();
		
		//Update view
		getView().setElementAmount(ResourceBarElement.WOOD, resourceHand.getCountByType(ResourceType.WOOD));
		getView().setElementAmount(ResourceBarElement.BRICK, resourceHand.getCountByType(ResourceType.BRICK));
		getView().setElementAmount(ResourceBarElement.SHEEP, resourceHand.getCountByType(ResourceType.SHEEP));
		getView().setElementAmount(ResourceBarElement.WHEAT, resourceHand.getCountByType(ResourceType.WHEAT));
		getView().setElementAmount(ResourceBarElement.ORE, resourceHand.getCountByType(ResourceType.ORE));

		getView().setElementAmount(ResourceBarElement.ROAD, currentUser.getUnusedRoads());
		getView().setElementAmount(ResourceBarElement.SOLDIERS, currentUser.getSoldiers());
		getView().setElementAmount(ResourceBarElement.SETTLEMENT, currentUser.getUnusedSettlements());
		getView().setElementAmount(ResourceBarElement.CITY, currentUser.getUnusedCities());
		
		//Enable Buttons
		if (currentUser.getUnusedRoads() == 0)
		{
			getView().setElementEnabled(ResourceBarElement.ROAD, false);
		}
		else
		{
			getView().setElementEnabled(ResourceBarElement.ROAD, 
					facade.canBuyPiece(turnManager, currentUser, PieceType.ROAD));
		}
		
		if (currentUser.getUnusedSettlements() == 0)
		{
			getView().setElementEnabled(ResourceBarElement.SETTLEMENT, false);
		}
		else
		{
			getView().setElementEnabled(ResourceBarElement.SETTLEMENT, 
					facade.canBuyPiece(turnManager, currentUser, PieceType.SETTLEMENT));
		}
		
		
		if (currentUser.getUnusedCities() == 0)
		{
			getView().setElementEnabled(ResourceBarElement.CITY, 
					false);
		}
		else
		{
			getView().setElementEnabled(ResourceBarElement.CITY, 
					facade.canBuyPiece(turnManager, currentUser, PieceType.CITY));
		}
			
		getView().setElementEnabled(ResourceBarElement.BUY_CARD, facade.canBuyDevCard(turnManager, currentUser, bank.getDevCardDeck()));
		
		setPlayDev();
	}

	public void setPlayDev(){
		boolean canPlay = false;
		ClientManager cm = ClientManager.instance();
		ModelFacade facade = cm.getModelFacade();
		PlayerInfo player = cm.getCurrentPlayerInfo();
		TurnManager turnManager = facade.turnManager();
		int currentID = player.getId();
		User currentUser = facade.turnManager().getUserFromID(currentID);
		
		if (facade.canPlayDevCard(turnManager, currentUser, new DevCard(DevCardType.MONOPOLY)))
			canPlay = true;
		if (facade.canPlayDevCard(turnManager, currentUser, new DevCard(DevCardType.MONUMENT)))
			canPlay = true;
		if (facade.canPlayDevCard(turnManager, currentUser, new DevCard(DevCardType.ROAD_BUILD)))
			canPlay = true;
		if (facade.canPlayDevCard(turnManager, currentUser, new DevCard(DevCardType.SOLDIER)))
			canPlay = true;
		if (facade.canPlayDevCard(turnManager, currentUser, new DevCard(DevCardType.YEAR_OF_PLENTY)))
			canPlay = true;
		
		getView().setElementEnabled(ResourceBarElement.PLAY_CARD, canPlay);
	}
}

